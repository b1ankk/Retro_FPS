#include "GameTime.h"

double game::GameTime::deltaTime_ = 0.;