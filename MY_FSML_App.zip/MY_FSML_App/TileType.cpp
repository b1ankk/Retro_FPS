#include "TileType.h"


namespace game
{
    int TileType::nextId_ = 0;


    
}
