#include "Game.h"

int main(int argc, char** argv)
{
    
    game::Game::get().start();


}
